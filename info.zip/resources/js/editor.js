import domReady from '@wordpress/dom-ready';

domReady(() => {
  //
});

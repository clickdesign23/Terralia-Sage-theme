{{-- 
  Template Name: Home Page
--}}

@extends('layouts.app')

@section('content')

    <!-- ****************************************************Main Banner Section************************************************ -->
  <section class="hero-section d-flex">
    <div class="container-fluid">
      <div class="row">
        <!-- Content Column -->
        <div class="col-lg-6 d-flex align-items-start h-100 position-relative overflow-hidden">
          <div class="hero-content p-4 ps-lg-5">
            <h1 class="mb-4">
              Promoteur immobilier en<br>
              Lorraine et Normandie
            </h1>
            <p class="mb-4">
              Lorem ipsum dolor sit amet consectetur. Enim<br>
              blandit risus fermentum quis. Tincidunt non<br>
              massa eget nunc eget fringilla. Nam adipiscing<br>
              elit consequat molestie adipiscing dui.
            </p>

            <div class="property-types d-flex flex-column gap-3 mb-4">
              <div class="form-check">
                <input class="form-check-input" type="radio" name="type" id="type1" checked>
                <label class="form-check-label" for="type1">
                  Appartement neuf
                </label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="type" id="type2">
                <label class="form-check-label" for="type2">
                  Appartement renové
                </label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="type" id="type3">
                <label class="form-check-label" for="type3">
                  Maison
                </label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="type" id="type4">
                <label class="form-check-label" for="type4">
                  Terrain
                </label>
              </div>
            </div>

            <div class="search-bar d-flex gap-3 mt-3">
              <input type="text" class="form-control form-control-lg" placeholder="Ville ou code postal">
              <button class="btn btn-lg px-4">Rechercher</button>
            </div>
          </div>

          <div class="vertical-text d-none d-lg-flex flex-column position-absolute w-100">
            <div>ACHETER</div>
            <div>VENDRE</div>
          </div>
        </div>

        <!-- Image Column -->
        <div class="col-lg-6 hero-image"></div>
      </div>
    </div>
  </section>

  <!-- ***************************************************** Feature Section *************************************************-->
  <section class="feature-section py-5">
    <div class="container">
      <div class="row align-items-end">
        <!-- Heading Column -->
        <div class="col-lg-6 col-md-12 mb-4 mb-lg-0">
          <div class="feature-heading">
            <h2 class="mb-0">Programmes exclusifs<br>de votre promoteur immobilier</h2>
          </div>
        </div>

        <!-- Text Column -->
        <div class="col-lg-6 col-md-12">
          <div class="feature-text">
            <p class="mb-0">
              Lorem ipsum dolor sit amet consectetur. Enim blandit risus fermentum quis.
              Tincidunt non massa eget nunc eget fringilla. Nam adipiscing elit consequat molestie.
            </p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- **************************************************** product crousal ***************************************************-->

  <!--section class="program-section py-5 bg-white">

    <div class="program-slider">
    
      <div class="card border-0">
        <div class="position-relative">
          <img src="images/bien-image (1).jpg" class="img-fluid" alt="">
          <span class="badge-custom">Travaux en cours</span>
        </div>
        <div class="p-3">
          <div class="meta text-success">Thionville (57)</div>
          <h5 class="card-title mt-1">Le Domaine de Dyane, une résidence à la frontière du Luxembourg</h5>
          <p class="mb-1 mt-2">Dès 299 000 €</p>
          <p class="meta">Appartement neuf / T2 à T4 / Balcon / PTZ / Pinel</p>
          <hr>
          <button class="btn-discover">Découvrir</button>
        </div>
      </div>

    
      <div class="card border-0">
        <div class="position-relative">
          <img src="images/bien-image (2).jpg" class="img-fluid" alt="">
          <span class="badge-custom">Travaux en cours</span>
        </div>
        <div class="p-3">
          <div class="meta text-success">Morroy-le-Veneur (57)</div>
          <h5 class="card-title mt-1">Les Terrasses de Bellevue, une résidence neuve dans une impasse calme et
            résidentielle</h5>
          <p class="mb-1 mt-2">Dès 227 600 €</p>
          <p class="meta">Appartement neuf / T2 à T3 / Jardins privatifs / Pinel</p>
          <hr>
          <button class="btn-discover">Découvrir</button>
        </div>
      </div>

    
      <div class="card border-0">
        <div class="position-relative">
          <img src="images/bien-image.jpg" class="img-fluid" alt="">
          <span class="badge-custom">Travaux en cours</span>
        </div>
        <div class="p-3">
          <div class="meta text-success">Metz (57)</div>
          <h5 class="card-title mt-1">Les duplex de Chieulles, 4 maisons–duplex près de Metz</h5>
          <p class="mb-1 mt-2">Dès 282 000 €</p>
          <p class="meta">Appartement neuf / T2 à T4 / Balcon / PTZ / Pinel</p>
          <hr>
          <button class="btn-discover">Découvrir</button>
        </div>
      </div>
     
      <div class="card border-0">
        <div class="position-relative">
          <img src="images/bien-image (1).jpg" class="img-fluid" alt="">
          <span class="badge-custom">Travaux en cours</span>
        </div>
        <div class="p-3">
          <div class="meta text-success">Metz (57)</div>
          <h5 class="card-title mt-1">Les duplex de Chieulles, 4 maisons–duplex près de Metz</h5>
          <p class="mb-1 mt-2">Dès 282 000 €</p>
          <p class="meta">Appartement neuf / T2 à T4 / Balcon / PTZ / Pinel</p>
          <hr>
          <button class="btn-discover">Découvrir</button>
        </div>
      </div>
    </div>

  </section-->  

  <section class="program-section py-5 bg-white">
    <?php if (have_rows('program_slider')): ?>
        <div class="program-slider">
            <?php while (have_rows('program_slider')): the_row(); 
                $image = get_sub_field('image');
                $badge = get_sub_field('badge');
                $location = get_sub_field('location');
                $title = get_sub_field('title');
                $price = get_sub_field('price');
                $details = get_sub_field('details');
                $button_link = get_sub_field('button_link');
            ?>
            
            <!-- Dynamic Card -->
            <div class="card border-0">
                <div class="position-relative">
                    <?php if ($image): ?>
                        <img src="<?php echo esc_url($image['url']); ?>" class="img-fluid" alt="<?php echo esc_attr($image['alt']); ?>">
                    <?php endif; ?>
                    
                    <?php if ($badge): ?>
                        <span class="badge-custom"><?php echo esc_html($badge); ?></span>
                    <?php endif; ?>
                </div>
                <div class="p-3">
                    <?php if ($location): ?>
                        <div class="meta text-success"><?php echo esc_html($location); ?></div>
                    <?php endif; ?>
                    
                    <?php if ($title): ?>
                        <h5 class="card-title mt-1"><?php echo esc_html($title); ?></h5>
                    <?php endif; ?>
                    
                    <?php if ($price): ?>
                        <p class="mb-1 mt-2"><?php echo esc_html($price); ?></p>
                    <?php endif; ?>
                    
                    <?php if ($details): ?>
                        <p class="meta"><?php echo esc_html($details); ?></p>
                    <?php endif; ?>
                    
                    <hr>
                    
                    <?php if ($button_link): ?>
                        <a href="<?php echo esc_url($button_link); ?>" class="btn-discover">Découvrir</a>
                    <?php endif; ?>
                </div>
            </div>
            <!-- End Dynamic Card -->
            
            <?php endwhile; ?>
        </div>
    <?php endif; ?>
</section>

  <!-- **************************************************** 2colum section section **************************************************** -->

  <!--div class="container-fluid section Terrain-sec">
    <div class="row align-items-center">

    
      <div class="col-lg-6 mb-4 mb-lg-0">
        <img src="images/Frame 58.jpg" alt="Terrain à vendre" class="img-fluid w-100 rounded">
      </div>

    
      <div class="col-lg-6 right-side-content">
        <p class="subtitle">Terrain à vendre</p>
        <h2 class="fw-bold mb-4">Trouver un terrain à vendre pour construire sa maison de demain</h2>
        <p>Grâce à son expertise, elle sélectionne avec soin les terrains, partenaires et entreprises, garantissant
          ainsi des offres d'une qualité irréprochable.</p>
        <p>Les terrains proposés sont aménagés, viabilisés, libres de constructeur, idéalement situés et d'une surface
          diversifiée, offrant à chacun la possibilité de réaliser son projet de construction en toute confiance et
          tranquillité.</p>

        <div class="mt-4 d-flex align-items-center">
          <button class="btn btn-main me-3">Trouver votre terrain</button>
          <a href="#" class="btn-link-arrow">Vendre un terrain →</a>
        </div>
      </div>

    </div>
  </div -->


    @php
    $terrain_image = get_field('terrain_image');
    $terrain_subtitle = get_field('terrain_subtitle');
    $terrain_title = get_field('terrain_title');
    $terrain_description_1 = get_field('terrain_description_1');
    $terrain_description_2 = get_field('terrain_description_2');
    $terrain_button_text = get_field('terrain_button_text');
    $terrain_button_link = get_field('terrain_button_link');
    $terrain_link_text = get_field('terrain_link_text');
    $terrain_link_url = get_field('terrain_link_url');
    
  @endphp

  <div class="container-fluid section Terrain-sec">
  <div class="row align-items-center">

    {{-- Left Image --}}
    <div class="col-lg-6 mb-4 mb-lg-0">
      @if(is_array($terrain_image))
        <img src="{{ $terrain_image['url'] }}" 
             alt="{{ $terrain_image['alt'] ?: $terrain_subtitle }}" 
             class="img-fluid w-100 rounded">
      @else
        <img src="{{ $terrain_image }}" 
             alt="{{ $terrain_subtitle }}" 
             class="img-fluid w-100 rounded">
      @endif
    </div>

    {{-- Right Content --}}
    <div class="col-lg-6 right-side-content">
      @if($terrain_subtitle)
        <p class="subtitle">{{ $terrain_subtitle }}</p>
      @endif
      
      @if($terrain_title)
        <h2 class="fw-bold mb-4">{{ $terrain_title }}</h2>
      @endif
      
      @if($terrain_description_1)
        <p>{{ $terrain_description_1 }}</p>
      @endif
      
      @if($terrain_description_2)
        <p>{{ $terrain_description_2 }}</p>
      @endif

      <div class="mt-4 d-flex align-items-center">
        @if($terrain_button_text && $terrain_button_link)
          <a href="{{ $terrain_button_link }}" class="btn btn-main me-3">
            {{ $terrain_button_text }}
          </a>
        @endif
        
        @if($terrain_link_text && $terrain_link_url)
          <a href="{{ $terrain_link_url }}" class="btn-link-arrow">
            {{ $terrain_link_text }} →
          </a>
        @endif
      </div>
    </div>

  </div>
</div>



  <!-- ***************************************** Pourquoi confier votre projet à Terralia Immobilier ? section ******************************************* -->

  <div class="container-fluid dark-section">
    <div class="container">
      <div class="row align-items-start dark-sec-container">

        <!-- Left Column -->
        <div class="col-lg-6 mb-5 mb-lg-0 dark-left-sec">
          <h2 class="fw-bold mb-4 dark-left-sec-title">Pourquoi confier votre projet à Terralia Immobilier ?</h2>
          <img src="images/house.png" alt="Home Icon" class="left-icon">
        </div>

        <!-- Right Column -->
        <div class="col-lg-6 dark-right-sec">
          <div class="feature-block">
            <h3>20 ans d'expérience au service de l'aménagement urbain</h3>
          </div>
          <div class="feature-block">
            <h3>40 collaborateurs expérimentés et à votre service</h3>
          </div>
          <div class="feature-block">
            <h3>Une politique responsabilité sociétale et environnementale forte</h3>
          </div>
          <div class="feature-block">
            <h3 class="text-white">Des partenariats stratégiques pour des projets réussis</h3>
            <p class="mb-0">Terralia Immobilier s’associe avec des collectivités et des partenaires immobiliers et
              financiers de renom tels que : Claude Rizzon, ICADE, Vivest, AFEDIM, Amundi Asset Management…</p>
          </div>
        </div>

      </div>
    </div>
  </div>






  <!-- ***************************************** Conseils et astuces section ******************************************* -->
  <section class="py-5">
    <div class="container">
      <div class="row conseils-section">

        <!-- Left Column -->
        <div class="col-md-6 mb-4 mb-md-0 conseils-left-col">
          <h2 class="fw-bold mb-5 left-title">Conseils et <br> astuces</h2>
          <div class="bg-light p-3 shadow-sm rounded position-relative">
            <small class="text-uppercase fw-semibold text-muted">Conseil du mois</small>
            <img src="images/image (1).jpg" alt="Main article" class="img-fluid my-3 w-100">
            <h5 class="fw-bold">Baisse des taux de la BCE et projet de loi de finances 2025</h5>
            <p class="text-muted small mb-4">
              Lorem ipsum dolor sit amet consectetur. Enim blandit risus fermentum quis.
              Tincidunt non massa eget nunc eget fringilla. Nam adipiscing elit...
            </p>
            <div class="d-flex align-items-center">
              <span class="badge text-black px-2 py-2 me-2 custom-bg">CONSEIL</span>
              <small class="text-muted">23.02.2025</small>
            </div>
          </div>
        </div>

        <!-- Right Column -->
        <div class="col-md-6 conseils-right-col">
          <p class="text-muted mb-5 right-text">
            Choisissez un terrain viabilisé, informez-vous sur les aides financières, et prenez en compte
            l’accessibilité et la valorisation future.
          </p>

          <!-- Articles List -->
          <div class="d-flex mb-5">
            <img src="images/image (2).jpg" class="me-3" style="width: 150px; height: auto; object-fit: contain;"
              alt="event1">
            <div>
              <h6 class="fw-bold mb-1 fs-5 text-black mb-3">Une soirée pour « tout casser » avant la construction de la
                résidence Cadence</h6>
              <div class="d-flex align-items-center">
                <span class="badge text-black px-2 py-2 me-2 custom-bg">ÉVÉNEMENT</span>
                <small class="text-muted">13.11.2023</small>
              </div>
            </div>
          </div>

          <div class="d-flex mb-5">
            <img src="images/image (3).jpg" class="me-3" style="width: 150px; height: auto; object-fit: contain;"
              alt="event2">
            <div>
              <h6 class="fw-bold mb-1 fs-5 text-black mb-3">Livraison de plusieurs résidences dans le Grand Est</h6>
              <div class="d-flex align-items-center">
                <span class="badge text-black px-2 py-2 me-2 custom-bg">ÉVÉNEMENT</span>
                <small class="text-muted">23.02.2025</small>
              </div>
            </div>
          </div>

          <div class="d-flex">
            <img src="images/image (4).jpg" class="me-3" style="width: 150px; height: auto; object-fit: contain;"
              alt="event3">
            <div>
              <h6 class="fw-bold mb-1 fs-5 text-black mb-3">Livraison et avancement des projets de notre lotissement aux
                portes de Metz</h6>
              <div class="d-flex align-items-center">
                <span class="badge text-black px-2 py-2 me-2 custom-bg">TRAVAUX</span>
                <small class="text-muted">23.02.2025</small>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  </section>


  <!-- ***************************************** Testimonials section ******************************************* -->
  <section class="py-5 bg-light testimonials-sec">
    <div class="container1">
      <div class="row align-items-center py-3">
        <h3 class="mb-4 text-center text-black fs-1">Foire aux questions</h3>
      </div>
      <div class="testimonials">
        <!-- testimonial 1 -->
        <div class="bg-white px-5 py-4 rounded-3 tesitimonial-slider">
          <p class="fs-6 small mb-4 lh-base text-black">Lorem ipsum dolor sit amet consectetur. Faucibus laoreet sit pretium non etiam faucibus ut. Aenean ullamcorper eget ultrices mattis id.</p>

         <p class="fs-6 small mb-4 lh-base text-black">Auctor scelerisque purus urna faucibus. Turpis eget consectetur morbi mattis nunc ornare suscipit fames. Nibh varius non odio ac placerat. Sed phasellus mi in erat adipiscing ut.</p>
        </div>
        <!-- testimonial 2 -->
        <div class="bg-white px-5 py-4 rounded-3 tesitimonial-slider">
          <p class="fs-6 small mb-4 lh-base text-black">Lorem ipsum dolor sit amet consectetur. Faucibus laoreet sit pretium non etiam faucibus ut. Aenean ullamcorper eget ultrices mattis id.</p>

         <p class="fs-6 small mb-4 lh-base text-black">Auctor scelerisque purus urna faucibus. Turpis eget consectetur morbi mattis nunc ornare suscipit fames. Nibh varius non odio ac placerat. Sed phasellus mi in erat adipiscing ut.</p>
        </div>
        <!-- testimonial 3 -->
        <div class="bg-white px-5 py-4 rounded-3 tesitimonial-slider">
          <p class="fs-6 small mb-4 lh-base text-black">Lorem ipsum dolor sit amet consectetur. Faucibus laoreet sit pretium non etiam faucibus ut. Aenean ullamcorper eget ultrices mattis id.</p>

         <p class="fs-6 small mb-4 lh-base text-black">Auctor scelerisque purus urna faucibus. Turpis eget consectetur morbi mattis nunc ornare suscipit fames. Nibh varius non odio ac placerat. Sed phasellus mi in erat adipiscing ut.</p>
        </div>
        <!-- testimonial 4 -->
        <div class="bg-white px-5 py-4 rounded-3 tesitimonial-slider">
          <p class="fs-6 small mb-4 lh-base text-black">Lorem ipsum dolor sit amet consectetur. Faucibus laoreet sit pretium non etiam faucibus ut. Aenean ullamcorper eget ultrices mattis id.</p>

         <p class="fs-6 small mb-4 lh-base text-black">Auctor scelerisque purus urna faucibus. Turpis eget consectetur morbi mattis nunc ornare suscipit fames. Nibh varius non odio ac placerat. Sed phasellus mi in erat adipiscing ut.</p>
        </div>
        <!-- testimonial 5 -->
        <div class="bg-white px-5 py-4 rounded-3 tesitimonial-slider">
          <p class="fs-6 small mb-4 lh-base text-black">Lorem ipsum dolor sit amet consectetur. Faucibus laoreet sit pretium non etiam faucibus ut. Aenean ullamcorper eget ultrices mattis id.</p>

         <p class="fs-6 small mb-4 lh-base text-black">Auctor scelerisque purus urna faucibus. Turpis eget consectetur morbi mattis nunc ornare suscipit fames. Nibh varius non odio ac placerat. Sed phasellus mi in erat adipiscing ut.</p>
        </div>
      </div>
    </div>
  </section>








  <!-- ***************************************** get product ideas to contact us ***************************************** -->
  <section class="py-5 text-white contact-sec" style="background-image: url('images/Frame\ 33.jpg');">
    <div class="container">
      <div class="row align-items-center py-5">

        <!-- Left Content -->
        <div class="col-md-8 mb-4 mb-md-0 py-5 contact-left-content">
          <h2 class="display-5 fw-bold title">
            Discutons de <i class="fst-italic text-opacity-75">votre projet</i> dès maintenant
          </h2>
          <p class="mt-3 text-light small text" style="padding-right: 130px; line-height: 1.5;">
            Discutons de votre projet pour comprendre vos attentes, choisir le terrain ou l’appartement idéal, et vous
            guider dans les démarches.
          </p>
        </div>

        <!-- Right Contact Buttons -->
        <div class="col-md-4 text-md-end">
          <a href="#contact" class="btn btn-dark mb-5">Nous contacter</a><br />
          <a href="tel:0387500300" class="btn btn-light d-inline-flex align-items-center">
            <i class="bi bi-telephone-fill me-2"></i>03 87 500 300
          </a>
        </div>

      </div>
    </div>
  </section>





  <!-- ***************************************** faq section ***************************************** -->
  <div class="container py-5 faq-sec">
    <div class="row align-items-center">

      <!-- Left Column -->
      <div class="col-lg-6 mb-4 mb-lg-0 faq-left-column">
        <img src="images/Rectangle 38.jpg" alt="Parrainage" class="img-fluid rounded mb-3">
        <div class="faq-left-content">
          <h3 class="fs-1 fw-bold text-black lh-1 title">Devenez <span class="highlight">parrain</span><br>Terralia
            Immobilier</h3>
          <p class="fs-6 small mb-4 lh-base">Parrainez vos proches et faites leur découvrir l'expérience de l'immobilier
            avec Terralia Immobilier. Très simple, devenez maintenant un parrain pour vous apporter une belle récompense
            !</p>
          <a href="#" class="btn btn-dark">Découvrir le parrainage</a>
        </div>

      </div>

      <!-- Right Column -->
      <div class="col-lg-6 faq-right-column">
        <h3 class="mb-4 text-center text-black fs-1">Foire aux questions</h3>
        <div class="accordion" id="faqAccordion">
          <div class="accordion-item">
            <h2 class="accordion-header">
              <button class="fs-5 accordion-button faq-question" type="button" data-bs-toggle="collapse"
                data-bs-target="#faq1">
                Blandit convallis venenatis purus ultrices ac imperdiet tortor ?
              </button>
            </h2>
            <div id="faq1" class="small accordion-collapse collapse show" data-bs-parent="#faqAccordion">
              <div class="accordion-body">
                Elementum facilisis enim a lorem ac gravida ut cursus...
              </div>
            </div>
          </div>

          <div class="accordion-item">
            <h2 class="accordion-header">
              <button class="fs-5 accordion-button collapsed faq-question" type="button" data-bs-toggle="collapse"
                data-bs-target="#faq2">
                Non sagittis ante amet ut sed ?
              </button>
            </h2>
            <div id="faq2" class="small accordion-collapse collapse" data-bs-parent="#faqAccordion">
              <div class="accordion-body">
                Velit amet in eu commodo porttitor a aliquam ut...
              </div>
            </div>
          </div>

          <div class="accordion-item">
            <h2 class="accordion-header">
              <button class="fs-5 accordion-button collapsed faq-question" type="button" data-bs-toggle="collapse"
                data-bs-target="#faq3">
                Donec tortor proin donec eu libero dui ?
              </button>
            </h2>
            <div id="faq3" class="small accordion-collapse collapse" data-bs-parent="#faqAccordion">
              <div class="accordion-body">
                Nulla facilisi morbi tempus imperdiet libero...
              </div>
            </div>
          </div>

          <div class="accordion-item">
            <h2 class="accordion-header">
              <button class="fs-5 accordion-button collapsed faq-question" type="button" data-bs-toggle="collapse"
                data-bs-target="#faq4">
                Ut adipiscing est eget tempor amet ut tempor ?
              </button>
            </h2>
            <div id="faq4" class="small accordion-collapse collapse" data-bs-parent="#faqAccordion">
              <div class="accordion-body">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit...
              </div>
            </div>
          </div>

          <div class="accordion-item">
            <h2 class="accordion-header">
              <button class="fs-5 accordion-button collapsed faq-question" type="button" data-bs-toggle="collapse"
                data-bs-target="#faq5">
                Faucibus ut ut elementum viverra nulla fringilla ?
              </button>
            </h2>
            <div id="faq5" class="small accordion-collapse collapse" data-bs-parent="#faqAccordion">
              <div class="accordion-body">
                Proin viverra massa sit amet erat efficitur, sed fringilla...
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
@endsection
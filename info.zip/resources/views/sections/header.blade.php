<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Terralia Immobilier</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Host+Grotesk:ital,wght@0,300..800;1,300..800&family=JetBrains+Mono:ital,wght@0,100..800;1,100..800&display=swap"
    rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css" />

  <link rel="stylesheet" href="css/custom.css">

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

  <!-- jQuery + Slick JS -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>

</head>

<body>

  <header>
    <!-- Top Contact Info -->
    <div class="bg-light text-end small px-3 py-1 border-bottom">
      <div class="container">
        <span class="me-3 text-uppercase">Le Groupe</span>
        <span class="me-3 text-uppercase">Conseils et Actus</span>
        <span class="me-3">/</span>
        <strong>03 87 500 300</strong>
      </div>
    </div>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-white bg-white border-bottom">
      <div class="container">
        <!-- Logo -->
        <a class="navbar-brand d-flex align-items-center" href="#">
         <img src="https://terralia-immobilier.preprodwi.fr/app/uploads/2025/05/logo.png" alt="Logo" class="me-2">
          <!-- <div>
          <strong class="d-block">Terralia</strong>
          <small class="text-success">Immobilier</small>
        </div> -->
        </a>

        <!-- Menu Items -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse justify-content-end" id="mainNav">
          <ul class="navbar-nav align-items-center mb-2 mb-lg-0">
            <li class="nav-item"><a class="nav-link" href="#">Appartements</a></li>
            <li class="nav-item"><a class="nav-link" href="#">Maisons</a></li>
            <li class="nav-item"><a class="nav-link" href="#">Terrains</a></li>
            <li class="nav-item"><a class="nav-link" href="#">Nos services</a></li>
            <li class="nav-item ms-2">
              <a href="#" class="btn btn-contact">Nous contacter</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  </header>

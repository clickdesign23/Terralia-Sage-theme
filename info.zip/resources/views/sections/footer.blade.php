 <footer class="bg-light pt-5">
    <div class="container">
      <div class="row">
        <!-- Logo and Description -->
        <div class="col-md-4 mb-4">
          <div class="d-flex align-items-center mb-3">
            <img src="images/logo.png" alt="Terralia Logo" class="me-2">
            <!-- <div>
            <div class="fw-bold fs-5">Terralia</div>
            <div class="text-success small">Immobilier</div>
          </div> -->
          </div>
          <p class="small text-muted mb-2">
            Des lotissements disponibles ou en cours de construction sur votre secteur, un grand choix de Terrains
            viabilisés libres de constructeur et des Programmes Immobiliers de standing pour devenir propriétaire d’un
            appartement neuf.
          </p>
        </div>

        <!-- Achat et Vente -->
        <div class="col-md-3 mb-4">
          <h6 class="text-uppercase text-muted small fw-semibold mb-3">Achat et Vente</h6>
          <ul class="list-unstyled">
            <li><a href="#" class="text-dark text-decoration-none">Appartements</a></li>
            <li><a href="#" class="text-dark text-decoration-none">Maisons</a></li>
            <li><a href="#" class="text-dark text-decoration-none">Terrains</a></li>
            <li><a href="#" class="text-dark text-decoration-none">Services</a></li>
          </ul>
        </div>

        <!-- Terralia Immobilier -->
        <div class="col-md-3 mb-4">
          <h6 class="text-uppercase text-muted small fw-semibold mb-3">Terralia Immobilier</h6>
          <ul class="list-unstyled">
            <li><a href="#" class="text-dark text-decoration-none">Le groupe</a></li>
            <li><a href="#" class="text-dark text-decoration-none">Blog</a></li>
            <li><a href="#" class="text-dark text-decoration-none">Nous contacter</a></li>
          </ul>
        </div>

        <!-- Nous Suivre -->
        <div class="col-md-2 mb-4">
          <h6 class="text-uppercase text-muted small fw-semibold mb-3">Nous Suivre</h6>
          <ul class="list-unstyled">
            <li><a href="#" class="text-dark text-decoration-none">Facebook</a></li>
            <li><a href="#" class="text-dark text-decoration-none">LinkedIn</a></li>
            <li><a href="#" class="text-dark text-decoration-none">Instagram</a></li>
            <li><a href="#" class="text-dark text-decoration-none">X</a></li>
            <li><a href="#" class="text-dark text-decoration-none">YouTube</a></li>
          </ul>
        </div>
      </div>
    </div>

    <!-- Bottom Bar -->
    <div class="bg-light border-top mt-4">
      <div class="container py-3">
        <div class="row text-center text-md-start align-items-center">
          <div class="col-md-4 small text-muted mb-2 mb-md-0">
            © 2025 Terralia Immobilier
          </div>
          <div class="col-md-4 mb-2 mb-md-0 d-flex justify-content-center">
            <a href="#" class="text-muted small text-decoration-none me-3">Mentions légales</a>
            <a href="#" class="text-muted small text-decoration-none">Confidentialité</a>
          </div>
          <div class="col-md-4 text-md-end small text-muted">
            Une création <span class="fw-semibold text-dark">Web Idea</span>
          </div>
        </div>
      </div>
    </div>
  </footer>
